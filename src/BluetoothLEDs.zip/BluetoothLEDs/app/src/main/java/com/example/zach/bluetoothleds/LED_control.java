package com.example.zach.bluetoothleds;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOError;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class LED_control extends AppCompatActivity {
    private static final String TAG = "bluetooth1";

    Button btnOn, btnOff, btnList;
    ListView listView;

    private BluetoothAdapter btAdapter = null;
    private BluetoothSocket btSocket = null;
    private OutputStream outStream = null;

    private Set<BluetoothDevice> pairedDevices;

    // Set to use the SPP UUID service
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // MAC-address of Bluetooth module
    private static String address = "00:00:00:00:00:00"; // = "20:16:01:20:33:91";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_led_control);

        btnOn = (Button) findViewById(R.id.btnOn);
        btnOff = (Button) findViewById(R.id.btnOff);
        btnList = (Button) findViewById(R.id.listBtn);

        btAdapter = BluetoothAdapter.getDefaultAdapter();
        Toast.makeText(getBaseContext(), address, Toast.LENGTH_LONG).show();
        Log.d(TAG, "Address: " + address);
        listView = (ListView) findViewById(R.id.devList);
        checkBTState();

        btnOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("1");
                Toast.makeText(getBaseContext(), "Turned LED on", Toast.LENGTH_SHORT).show();
            }
        });

        btnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("0");
                Toast.makeText(getBaseContext(), "Turned LED off", Toast.LENGTH_SHORT).show();
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                view.setSelected(true);
                String selectedDevice = (String) (listView.getItemAtPosition(position));
                Log.d(TAG, "Selected Item: " + selectedDevice);
                address = selectedDevice.split("\n")[1]; // Get address of selected device
                Log.d(TAG, "Selected Item - Parsed Address: " + address);
                connectDevice();
            }
        });
    }

    public void list(View v) {
        pairedDevices = btAdapter.getBondedDevices();
        ArrayList list = new ArrayList();

        if (pairedDevices.isEmpty()) {
            Log.e(TAG, "No devices paired...");
            Toast.makeText(getBaseContext(), "No devices paired...", Toast.LENGTH_SHORT).show();
            return;
        }

        for (BluetoothDevice device : pairedDevices) {
            list.add(device.getName() + "\n" + device.getAddress());
            Log.d(TAG, "Device (" + device.getName() + "): address : " + device.getAddress());
        }

        Toast.makeText(getApplicationContext(), "Showing paired devices", Toast.LENGTH_LONG).show();

        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
    }

    private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
        if(Build.VERSION.SDK_INT >= 10){
            try {
                final Method  m = device.getClass().getMethod("createInsecureRfcommSocketToServiceRecord", new Class[] { UUID.class });
                return (BluetoothSocket) m.invoke(device, MY_UUID);
            } catch (Exception e) {
                Log.e(TAG, "Could not create Insecure RFComm Connection",e);
            }
        }
        return  device.createRfcommSocketToServiceRecord(MY_UUID);
    }

    public void connectDevice() {
        // Set up a pointer to the remote using it's address.
        BluetoothDevice device = btAdapter.getRemoteDevice(address);

        // Two things are needed to make a connection:
        //      A MAC address, which we got above.
        //      A Service ID or UUID. In this case we are using the
        //      UUID for Serial Port Profile.

        try {
            btSocket = createBluetoothSocket(device);
        } catch (IOException e1) {
            errorExit("Fatal Error", "In connectDevice() and socket create failed: " + e1.getMessage() + ".");
        }

        // Discovery is resource intensive. Make sure it's not going on
        // when you attempt to connect and pass the message
        btAdapter.cancelDiscovery();

        // Establish a connection. This will block until it connects
        Log.d(TAG, "...Connecting...");
        try {
            btSocket.connect();
            Log.d(TAG, "...Connecting ok...");
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {
                errorExit("Fatal Error", "In connectDevice() and unable to close socket during connection failure" + e2.getMessage() + ".");
            }
        }

        // Create a data stream to talk to the server
        Log.d(TAG, "...Create Socket...");

        try {
            outStream = btSocket.getOutputStream();
            // Tell user the connection has been established
            Toast.makeText(getBaseContext(), "Connection established with " + device.getName(), Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            errorExit("Fatal Error", "In connectDevice() and output stream creation failed: " + e.getMessage() + ".");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.d(TAG, "...onResume - try connect...");

        connectDevice();
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.d(TAG, "...In onPause()...");

        if (outStream != null) {
            try {
                outStream.flush();
            } catch (IOException e) {
                errorExit("Fatal Error", "In onPause() and failed to flush output stream: " + e.getMessage() + ".");
            }
        }

        try {
            btSocket.close();
        } catch (IOException e2) {
            errorExit("Fatal Error", "In onPause() and failed to close socket: " + e2.getMessage() + ".");
        }
    }

    private void checkBTState() {
        // Check for Bluetooth support and then check to make sure it's enabled
        if (btAdapter == null) {
            errorExit("Fatal Error", "Bluetooth not supported");
        } else {
            if (btAdapter.isEnabled()) {
                Log.d(TAG, "...Bluetooth ON...");
            } else {
                // Prompt user to enable Bluetooth
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, 1);
            }
        }
    }

    private void errorExit(String title, String message) {
        Toast.makeText(getBaseContext(), title + " - " + message, Toast.LENGTH_LONG).show();
        finish();
    }

    private void sendData(String message) {
        byte[] msgBuffer = message.getBytes();

        Log.d(TAG, "...Send data: " + message + "...");

        try {
            outStream.write(msgBuffer);
        } catch (IOException e) {
            String msg = "In onResume() and an exception occurred during write: " + e.getMessage();
            if (address.equals("00:00:00:00:00:00"))
                msg = msg + ".\n\nUpdate your server address from 00:00:00:00:00:00 to the correct address";
            msg = msg + ".\n\nCheck that the SPP UUID: " + MY_UUID.toString() + " exists on server.\n\n";

            errorExit("Fatal Error", msg);
        }
    }
}
